# Sample Post 1

[Sample Post 2](./sample-post2.md)

[Sample Child Post 2](./sample-folder/sample-child-post2.md)

[Sample External Link](https://tressel.xyz)

## H2
### H3
#### H4