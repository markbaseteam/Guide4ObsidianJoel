# Sample Child Post 1

[Sample Post 1](../sample-post1.md)

[Sample Child Post 1](./sample-child-post1.md)

[Sample External Link](https://tressel.xyz)

## H2
### H3
#### H4